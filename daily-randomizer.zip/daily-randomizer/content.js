(function () {
  const existing = document.getElementById("daily-randomizer-widget");
  if (existing) {
    existing.remove();
    return;
  }

  const widget = document.createElement("div");
  widget.id = "daily-randomizer-widget";
  widget.innerHTML = `
    <div class="dr-header">
      <span class="dr-title">Daily Randomizer</span>
      <button class="dr-toggle" type="button" title="Minimizar">−</button>
    </div>
    <div class="dr-body">
      <button class="dr-randomize" type="button">Randomizar participantes</button>
      <p class="dr-status"></p>
      <ol class="dr-result"></ol>
    </div>
  `;
  document.body.appendChild(widget);

  const randomizeBtn = widget.querySelector(".dr-randomize");
  const toggleBtn = widget.querySelector(".dr-toggle");
  const header = widget.querySelector(".dr-header");
  const statusEl = widget.querySelector(".dr-status");
  const resultEl = widget.querySelector(".dr-result");

  randomizeBtn.addEventListener("click", () => {
    resultEl.innerHTML = "";
    statusEl.classList.remove("dr-error");

    const names = extractParticipants();

    if (names.length === 0) {
      statusEl.textContent = "Abre el panel de participantes en Meet.";
      statusEl.classList.add("dr-error");
      return;
    }

    shuffle(names);

    statusEl.textContent = `Orden aleatorio (${names.length}):`;
    for (const name of names) {
      const li = document.createElement("li");
      li.textContent = name;
      resultEl.appendChild(li);
    }
  });

  toggleBtn.addEventListener("click", () => {
    const collapsed = widget.classList.toggle("dr-collapsed");
    toggleBtn.textContent = collapsed ? "+" : "−";
    toggleBtn.title = collapsed ? "Expandir" : "Minimizar";
  });

  enableDrag(widget, header, toggleBtn);

  function extractParticipants() {
    const lists = document.querySelectorAll("div[role='list']");
    const names = [];
    for (const list of lists) {
      for (const item of list.children) {
        const first = item.children[0];
        const text = first?.innerText?.trim();
        if (text) names.push(text);
      }
    }
    return names;
  }

  function shuffle(items) {
    for (let i = items.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [items[i], items[j]] = [items[j], items[i]];
    }
  }

  function enableDrag(target, handle, ignoreEl) {
    let dragging = false;
    let offsetX = 0;
    let offsetY = 0;

    handle.addEventListener("mousedown", (e) => {
      if (e.target === ignoreEl) return;
      dragging = true;
      const rect = target.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;
      e.preventDefault();
    });

    document.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      target.style.left = `${e.clientX - offsetX}px`;
      target.style.top = `${e.clientY - offsetY}px`;
      target.style.right = "auto";
      target.style.bottom = "auto";
    });

    document.addEventListener("mouseup", () => {
      dragging = false;
    });
  }
})();
